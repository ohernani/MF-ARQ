import classes from './Button.module.scss';

export function Button() {
  return (
    <button className={classes.button}>
      Este es un boton de la libreria de componentes
    </button>
  );
}
